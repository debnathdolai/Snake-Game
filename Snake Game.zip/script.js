const snake = document.getElementById('snake');
const food = document.getElementById('food');
const upButton = document.getElementById('up');
const downButton = document.getElementById('down');
const leftButton = document.getElementById('left');
const rightButton = document.getElementById('right');
const scoreDisplay = document.getElementById('score');

let snakeX = 0;
let snakeY = 0;
let foodX;
let foodY;
let direction = 'right';
let score = 0;
const gridSize = 20;
const gameContainer = document.getElementById('game-container');

function randomPosition() {
    return Math.floor(Math.random() * gridSize) * gridSize;
}

function updateFoodPosition() {
    foodX = randomPosition();
    foodY = randomPosition();
    food.style.left = foodX + 'px';
    food.style.top = foodY + 'px';
}

function checkCollision() {
    if (
        snakeX < 0 ||
        snakeX >= gameContainer.clientWidth ||
        snakeY < 0 ||
        snakeY >= gameContainer.clientHeight
    ) {
        endGame();
    }
}

function updateScore() {
    score++;
    scoreDisplay.textContent = 'Score: ' + score;
}

function endGame() {
    alert('Game Over! Your Score: ' + score);
    location.reload(); // Reload the page to restart the game
}

function gameLoop() {
    switch (direction) {
        case 'right':
            snakeX += gridSize;
            break;
        case 'left':
            snakeX -= gridSize;
            break;
        case 'up':
            snakeY -= gridSize;
            break;
        case 'down':
            snakeY += gridSize;
            break;
    }

    snake.style.left = snakeX + 'px';
    snake.style.top = snakeY + 'px';

    checkCollision();

    // Check for collision with food
    if (snakeX === foodX && snakeY === foodY) {
        updateFoodPosition();
        updateScore();
    }

    setTimeout(gameLoop, 200);
}

upButton.addEventListener('click', () => {
    if (direction !== 'down') {
        direction = 'up';
    }
});

downButton.addEventListener('click', () => {
    if (direction !== 'up') {
        direction = 'down';
    }
});

leftButton.addEventListener('click', () => {
    if (direction !== 'right') {
        direction = 'left';
    }
});

rightButton.addEventListener('click', () => {
    if (direction !== 'left') {
        direction = 'right';
    }
});

updateFoodPosition();
gameLoop();
 